/**2)WAP to define a class Book with attributes id, name , 
price accept data for 5 objects display book with highest price.**/

package Assignment4;
import java.util.Scanner;

class Book
{
    int id;
    String name;
    double price,price1;
  
    
   void Student(int i,String n,double p)
    {
        id = i;
        name = n;
        price = p;
         
       
    }
    
    
    void display()
    {
        System.out.println("iD : " + id);
        System.out.println("Book name : " + name);
        System.out.println("price : " + price);
        
    }
}
  

class Que2
{
    public static void main(String args[])
    {
        Student s1 = new Student();
        s1.Student(1,"Book1",110);
        s1.display();
       
            
        System.out.println();
        
        Student s2 = new Student();
        s1.Student(2,"Book2",120);
        s1.display();
        
        System.out.println();
         
        Student s3 = new Student();
        s1.Student(3,"Book3",130);
        s1.display();
        
        System.out.println();
         
        Student s4 = new Student();
        s1.Student(4,"Book3",140);
        s1.display();
        
        System.out.println();
         
        Student s5 = new Student();
        s1.Student(5,"Book3",150);
        s1.display();
        

            
    }
}