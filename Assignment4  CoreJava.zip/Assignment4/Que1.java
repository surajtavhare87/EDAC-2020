/**1)WAP to define a class Student with attributes rollno, name , 
	marks accept data for 2 objects and display them.**/



package Assignment4;
import java.util.Scanner;

class Student
{
    int rollno;
    String name;
    double marks;
    
    void Student(int rn,String n,double m)
    {
        rollno = rn;
        name = n;
        marks = m;
    }
    void display()
    {
        System.out.println("Roll No : " + rollno);
         System.out.println("name : " + name);
          System.out.println("Marks : " + marks);
    }
}
class Que1
{
    public static void main(String args[])
    {
        Student s1 = new Student();
        s1.Student(87,"Ramesh",90);
        s1.display();
        
        System.out.println();
        
        Student s2 = new Student();
        s1.Student(88,"ASDFF",90);
        s1.display();
        
    }
}