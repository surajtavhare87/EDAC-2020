/*
Interface - School
class - student
class - Teacher
*/

interface school
{
    void display();
}

class student implements school
{
    String name;
    int id;
    String des;
 student(String name,int id,String des)
            {
        this.name = name;
        this.id = id;
        this.des = des;
            }
    public void display()
    {
        System.out.println("Name = "+ name);
        System.out.println("Id = "+ id);
        System.out.println("NDesignation = "+ des);
    }
 }

class teacher implements school
{
    String name;
    int id;
    String des;
     teacher(String name,int id,String des)
            {
        this.name = name;
        this.id = id;
        this.des = des;
            }
    public void display()
    {

        System.out.println("Name = "+ name);
        System.out.println("Id = "+ id);
        System.out.println("NDesignation = "+ des);
    }
 }

class que3
{
    public static void main(String args[])
    {
        student  s = new student("SS",12,"ffff");
     s.display();
        
        teacher t = new teacher("TT",13,"ffff");
        t.display();
    }
}