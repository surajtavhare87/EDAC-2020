/*
interface - company
class - employee
class - salaryS
*/
interface company
{
    void calculate();
}

class employee 
{
    void details();
}

class salary extends employee implements company
{
    int sal;
    String name;
    salary(int sal,String name)
    {
        this.sal = sal;
        this.name = name;
    }
    void calcuate()
    {
        
    }
}