/*
Interface - college
Interface - exam
Class - Student
//Display details of result
*/

interface college
{
    void name();
}

interface exam
{
    void marks();
}

class student1 implements college,exam
{
    String name;
    String collname;
    int id ;
    student1(String name)
    {
        this.name = name;
    }
        student1(String collname,int id)
    {
        this.collname = collname;
        this.id = id;
    }
    public void name()
    {
        System.out.println(name );
    }
   public void marks()
    {
           System.out.println(collname + id );
    }
}
class que4
{
    public static void main(String args[])
    {
        student1 s = new student1("aaa");
        student1 s1 = new student1("aaag",2);
        s.name();
        s1.marks();
        
    }
}