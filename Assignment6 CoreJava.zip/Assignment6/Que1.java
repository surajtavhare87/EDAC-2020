/*
Bank --> Customer
*/
interface bank
{
    void display();
}

class customer implements bank
{
    String name;
    int amount;
    String des;
 customer(String name,int amount,String des)
            {
        this.name = name;
        this.amount = amount;
        this.des = des;
            }
    public void display()
    {
        System.out.println("Name = "+ name);
        System.out.println("Amount = "+ amount);
        System.out.println("Account No = "+ des);
    }
 }

class que
{
    public static void main(String args[])
    {
        customer  s = new customer("Ramesh",12000,"Abc123");
        s.display();
        
     
    }
}