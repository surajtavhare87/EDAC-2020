package assignment2_pattern;
public class Pat5_Pyramid 
{
public static void main(String[] args) 

  {
      int i,j,k,sp=20,a; 
      for(i=9;i>=1;i--)
         {
              for(k=1;k<=sp;k++)
              {
                  System.out.print("  ");
              }
              sp--;
              for(j=i;j<=9;j++)
              {
                   System.out.print(j+" ");
              }
              
               for(a=8;a>=i;a--)
               {
                   System.out.print(a+" ");
               }
              
                   System.out.println();
          }
   }
}
        
    