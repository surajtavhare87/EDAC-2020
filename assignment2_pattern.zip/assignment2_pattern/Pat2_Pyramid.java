package assignment2_pattern;
public class Pat2_Pyramid
{
    public static void main(String[] args)
  {
      int i,j,k,sp=20; 
      for(i=1;i<=9;i++)
          {
              for(k=1;k<=sp;k++)
              {
                  System.out.print(" ");
              }
              sp--;
              for(j=1;j<=i;j++)
               {
                   System.out.print(j+" ");
               }
                   System.out.println("");
           }
   }
}
        