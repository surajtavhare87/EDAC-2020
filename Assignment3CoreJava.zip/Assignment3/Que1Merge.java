/**Write a program to merge two arrays of integers by reading one number at a time from each array
until one of the array is exhausted, and then concatenating the remaining numbers.
Input: [23,60,94,3,102] and [42,16,74]
Output: [23,42,60,16,94,74,3,102]**/
package Assignment3;
import java.util.Scanner;

class Que1Merge
{
    public static void main(String args[])
    {
        Scanner ss = new Scanner(System.in);
        
        
        //Scanner Input Array 1
        System.out.println("Enter Number of Elements in Array");
        int a = ss.nextInt();
        int arr1[] = new int[a];
        
        System.out.println("Enter Elements");
        for(int i =0;i<arr1.length;i++)
        {
            arr1[i] = ss.nextInt();
        }
        System.out.print("Array 1 =");
        for(int i:arr1)
        {
            System.out.print(i + " ");
        }
        
        
        //Scanner Input Array 2
        System.out.println();
        System.out.println("Enter Number of Elements in Array");
        int b = ss.nextInt();
        int arr2[] = new int[b];
        
        System.out.println("Enter Elements");
        for(int i =0;i<arr2.length;i++)
        {
            arr2[i] = ss.nextInt();
        }
        System.out.print("Array 2 =");
        for(int i:arr2)
        {
            System.out.print(i + " ");
        }
        System.out.println();
        for(int i = 0;i<5;i++)
        {
            System.out.print(arr1[i] +" , "+arr2[i]+" , ");
        }
        
        
        
    }  
 
}
