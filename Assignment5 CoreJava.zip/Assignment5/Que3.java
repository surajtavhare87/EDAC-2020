/*
3) Create a class MathOperation that has four static methods. 
add() method that takes two integer numbers as parameter and returns the sum of the numbers.
subtract() method that takes two integer numbers as parameter and returns the difference of the numbers.
multiply() method that takes two integer numbers as parameter and returns the product. 
power() method that takes two integer numbers as parameter
and returns the power of first number to second number. Create another class Demo (main class)
that takes the two numbers from the user and calls all four methods of MathOperation class by providing entered numbers and prints the return values of every method.
*/
import java.util.Scanner;
class MathOperation
{
        int a;
        int b;

static int add(int a,int b )
        {

            int add = a+b;
            return add;
        }


static int subtract(int a,int b )
        {

            int sub = a-b;
            return sub;
        }


static int multiply(int a,int b )
        {

            int mul = a*b;
            return mul;
        }


static int power(int a,int b )
        {

            double pow = (Math.pow(a,b));
            int pow1 = (int)pow;
            return pow1;
        }
}

class Demo
{
    public static void main(String args[])
    {
        Scanner s1 = new Scanner(System.in);
        System.out.println("Enter the Value of a");
        int a = s1.nextInt();
        System.out.println("Enter the Value of b");
        int b = s1.nextInt();
        
        MathOperation s = new MathOperation();
        System.out.println("Add = " + s.add(a,b));
        System.out.println("Subtract = " + s.subtract(a,b));
        System.out.println("Multiply = " + s.multiply(a,b));
        System.out.println("Power = " + s.power(a,b));
        
        
        
        
    }
}