/*
4.Create a class MathOperation containing overloaded methods ‘multiply’ to calculate multiplication of following arguments. 
a.two integers 
b.three floats 
c.all elements of array 
d.one double and one integer 

*/

class Mathoperation
{
    int mulInt(int a,int b)
    {
        return a*b;
    }
    
    float mulFloat(float a,float b,float c)
    {
        return a*b*c;
    }
    
   int mulArray( int arr[])
    {
        int a = 1;
        for(int i =0;i<arr.length;i++)
        {
            a = a* arr[i];
        }
        return a;
    }
    double muldbint(double a,int b)
    {
        return a*b; 
    }
}

class Calc
{
    public static void main(String args[])
    {
        int[] arr = {1,2,3,4,5};
        Mathoperation s = new Mathoperation();
        System.out.println("Two Integers = "+ s.mulInt(5, 7));
        System.out.println("Three Floats = "+ s.mulFloat(5.0f, 7.0f,5.0f));
        System.out.println("Array Elements = "+ s.mulArray(arr));
        System.out.println("One Double One Integer = "+ s.muldbint(5.0, 7));
    }
}